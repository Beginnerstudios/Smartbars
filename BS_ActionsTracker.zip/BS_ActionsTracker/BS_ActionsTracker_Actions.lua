--NameSpaces------------------------------
local _,BS_ActionsTracker = ...;
BS_ActionsTracker.Actions ={};
local Actions = BS_ActionsTracker.Actions;
--Init------------------------------------
function Actions:Init()
    UI = BS_ActionsTracker.UI
end
--Variables--------------------------------
local trackedActions = {}
local lastOffset =0
local isConfigMode


--Actions:Functions-----------------------
function Actions:GetUserActions2()
    local slotCount = 120
    local allSlotTable = {}
        for i=1,slotCount do
        local actionType,actionID,subType = GetActionInfo(i)
            if actionID ~=nil then
                allSlotTable[actionID] = {i,actionID,nil,""}           --- [1]slot id [2]spellID
            end
          end
         return allSlotTable
end

function Actions:GetUserActions()---test                                
    local returnTable =
        {                         
            GetUsed = function(self)
                local slotCount = 120
                local allSlotTable = {}
                for i=1,slotCount do
                local actionType,actionID,subType = GetActionInfo(i)
                if actionID ~=nil then
                allSlotTable[actionID] = {i,actionID,nil,""}           --- [1]slot id [2]spellID
            end
          end
          local count = 0
          for _ in pairs(allSlotTable) do count = count + 1 end    
         return {allSlotTable,count}
                               
            end,        
            GetTracked = function(self)                                              
                local count = 0
                for _ in pairs(trackedActions) do count = count + 1 end                              
                return  {trackedActions,count}  
            end                                           
        }
return returnTable
end
function Actions:AddTrackedAction(action)    
    local actionID = action[2]  
    if  trackedActions[actionID]then              
        trackedActions[actionID][3]:Hide() 
        trackedActions[actionID]=nil
        lastOffset = lastOffset -50
    else     
       trackedActions[actionID]= {action[1],action[2],UI:CreateActionWidget(action,UI:GetFrame(2)),action[4]} 
       UI:CreateEditBox(trackedActions[actionID][3])      
       trackedActions[actionID][3]:SetPoint("LEFT",UI:GetFrame(2).title,"LEFT",lastOffset,-30 ); 
       trackedActions[actionID][3]:SetScript("OnClick", function ()
    trackedActions[actionID][3].edit:SetFocus(true)
        end)
        trackedActions[actionID][3]:SetCheckedTexture(nil) 
        trackedActions[actionID][3]:SetHighlightTexture(nil) 
       trackedActions[actionID][3]:SetScript("OnUpdate", function ( )            
       Actions:HandleTrackedActionVisibility(trackedActions,actionID)
       if trackedActions~=nill then
       Actions:HandleEditBoxValues(trackedActions,actionID)
       end
        end)
  
       lastOffset = lastOffset +50   
    end       
    
    UI:UpdateUI()    
end                                                               
function Actions:InitTrackedActions(actions)    
    if actions ~=nill then
    for k,v in pairs(actions) do              
        local actionID = k
        isConfigMode = false
        actions[actionID]= {v[1],v[2],UI:CreateActionWidget(v,UI:GetFrame(2)),v[4]}               
        actions[actionID][3]:SetPoint("LEFT",UI:GetFrame(2).title,"LEFT",lastOffset,-40); 
        UI:CreateEditBox(actions[actionID][3]) 
        actions[actionID][3].edit:SetText(v[4]) 
        actions[actionID][3].edit:SetEnabled(false)             
        actions[actionID][3]:SetScript("OnUpdate", function ( )
            Actions:HandleTrackedActionVisibility(actions,actionID)
            end)
            Actions:HandleEditBoxValues(actions,actionID)
            local a, b, c, xOfs, e = actions[actionID][3]:GetPoint()  
            lastOffset = xOfs + 50
        end
        
    end
    

 

    UI:UpdateUI()
end  
function Actions:HandleTrackedActionVisibility(actions,actionID)      
       
        if isConfigMode then
            actions[actionID][3]:SetAlpha(1) 
            actions[actionID][3].edit:SetAlpha(1)                                    
        else
            local start, duration, enable = GetActionCooldown(actions[actionID][1])    
            local isUsable, notEnoughMana = IsUsableAction(actions[actionID][1]) 
            if actions[actionID][3].edit ~=nil then
            if enable>0 and duration>1.5 or notEnoughMana then                       
                actions[actionID][3]:SetAlpha(0) 
                actions[actionID][3].edit:SetAlpha(0) 
               
            elseif duration<1.5  then
                actions[actionID][3]:SetAlpha(1)                  
                actions[actionID][3].edit:SetAlpha(1)
            else       
                actions[actionID][3]:SetAlpha(1)  
                actions[actionID][3].edit:SetAlpha(1)
            end
        end
        end
        UI:SortTrackedActions(actions) 
end 
function Actions:HandleEditBoxValues(actions,actionID) 
  
         actions[actionID][3].edit:SetScript("OnEditFocusLost", function (self)             
         actions[actionID][4] = self:GetText()
         print("BS:ActionsTracker - Text saved to : "..self:GetText())
         end)
    
       
end    
--Getters & Setters,Reset-----------------------------
function Actions:GetIsConfigMode()
    return isConfigMode
end
function Actions:SetIsConfigMode(value)
    isConfigMode = value
end
function Actions:GetTrackedActions()
    return trackedActions
end 
 function Actions:SetTrackedActions(tActions)
    trackedActions = tActions
end 
function Actions:SetLastOffset(value)
    lastOffset = value
end         
function Actions:ResetActions()
trackedActions = nill
ReloadUI()
end

