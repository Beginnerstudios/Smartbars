--NameSpaces------------------------------
local _,BS_ActionsTracker = ...;
BS_ActionsTracker.Global ={};
-- Revision version v0.8.3 --
